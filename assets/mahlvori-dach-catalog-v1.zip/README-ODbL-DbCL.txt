Mahlvori DACH Open Food Facts catalog

This database is a derived selection from Open Food Facts product data.
Source: https://huggingface.co/datasets/openfoodfacts/product-database
Pinned source commit: 69acdceb31a30d23310c72120442d6d7d09e2d73
Countries: Germany, Austria and Switzerland. The selection includes products
with community-reported tags for EDEKA, REWE, ALDI, Lidl, Kaufland, PENNY,
Netto, BILLA, Hofer, SPAR, Migros, Coop and Denner.

Database license: Open Database License 1.0 (ODbL)
https://opendatacommons.org/licenses/odbl/1-0/
Individual data contents: Database Contents License 1.0 (DbCL)
https://opendatacommons.org/licenses/dbcl/1-0/
Open Food Facts reuse guidance:
https://openfoodfacts.github.io/documentation/docs/Product-Opener/api/tutorials/license-be-on-the-legal-side/

The derived database is made available under ODbL 1.0. Attribution, license,
and share-alike obligations apply. No product photographs or user data are
included. Retailer tags are community reported, may be incomplete or outdated,
and do not prove current assortment or stock in any store or branch.
